<!doctype html>
<html>

<head>
	<title>LOGIN</title>
	<link href='http://icons.iconarchive.com/icons/iconleak/cerulean/128/science-chemistry-icon.png' rel='SHORTCUT ICON' />
</head>

<index>
	<link rel="stylesheet" type="text/css" href="css/style2.css" />

	<body background="img/wallpaper/wallpaper-login.jpg">
		
			<div class ="container">
			<font size="+3" face="Bebas Neue">VEN's LAUNDRY ONLINE<br></font>
			<font size="2px" face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif">best premium laundry in Sidoarjo<br></font>
			<br>
			<form action="process/cekLogin.php" method="post" class="expose">

				<input type="text" size="25px" name="username" placeholder="Username" style="text-align:center"> <br /><br>
				<input type="password" size="25" name="password" id="password" placeholder="Password" style="text-align:center"><br /><br />
				<input type="submit" class="tombol" name="login" value="LOGIN">
				<br><br>
			</form>
			</div>
		

</index>
</body>

</html>